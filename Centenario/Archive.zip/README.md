Basado en el trabajo de Noah Veltman
http://noahveltman.com/subte

Diseño y programación: David Galavotti
Coordinación: Antonio Milanese

Fotografía y contenidos: Delfina Alvarez Saez y María Belén Alonso para SBASE

Creado en la Dirección General de Información y Gobierno Abierto

Ministerio de Modernización
Ciudad Autónoma de Buenos Aires